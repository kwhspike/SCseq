###整理数据
library(Seurat)
sce=Read10X_h5("GSE178341_crc10x_full_c295v4_submit.h5")
cluster=read.csv("GSE178341_crc10x_full_c295v4_submit_cluster.csv.gz")
metatable=read.csv("GSE178341_crc10x_full_c295v4_submit_metatables.csv.gz")
sce <- AddMetaData(object =sce, metadata = cluster)

# 假设 `sce` 是稀疏矩阵格式的基因表达数据
seurat_obj <- CreateSeuratObject(counts = sce)

# 确保 `cluster` 和 `seurat_obj` 的细胞名一致
# 提取 Seurat 对象的细胞名称
seurat_cell_ids <- colnames(seurat_obj)

# 检查 `cluster` 是否包含所有的 Seurat 细胞名称
if (all(seurat_cell_ids %in% cluster$sampleID)) {
  # 根据 cell IDs 对 `cluster` 进行排序，确保行顺序与 `seurat_obj` 一致
  cluster <- cluster %>% filter(sampleID %in% seurat_cell_ids) %>%
    arrange(match(sampleID, seurat_cell_ids))
  # 确保列名是 `sampleID`，用于与 `seurat_obj` 的细胞ID一致
  rownames(cluster) <- cluster$sampleID
  # 将 `cluster` 注释信息添加到 Seurat 对象的元数据中
  seurat_obj <- AddMetaData(seurat_obj, metadata = cluster)
} else {
  stop("Error: Cells in 'cluster' do not match cells in Seurat object 'sce'. Please check cell IDs.")
}
# 检查元数据是否成功添加
head(seurat_obj@meta.data)
library(qs)
qsave(seurat_obj,"sce.all.qs")
sce=qread("sce.all.qs")

table(sce@meta.data$cl295v11SubFull)

# 指定要提取的细胞亚群
selected_subtypes <- c(
  "cB1", "cB2", "cB3", 
  "cP1", "cP2", "cP3",
  "cM03", "cM04", "cM05", "cM06", "cM07", "cM08", "cM09",
  "cS01", "cS02", "cS03", "cS04", "cS05", "cS06", "cS07", "cS08", "cS09", "cS10", "cS11", "cS12", "cS13", "cS14",
  "cS21", "cS22", "cS23", "cS24", "cS25", "cS26", "cS27", "cS28", "cS29", "cS30", "cS31",
  "cTNI01", "cTNI02", "cTNI03", "cTNI04", "cTNI05", "cTNI06", "cTNI07", "cTNI08", "cTNI09",
  "cTNI10", "cTNI11", "cTNI12", "cTNI13", "cTNI14", "cTNI15", "cTNI16", "cTNI17", "cTNI18", "cTNI19", "cTNI20", "cTNI21", "cTNI22"
)
# 使用Seurat的subset函数提取指定细胞亚群
sce.need <- subset(sce, subset = cl295v11SubShort %in% selected_subtypes)
# 检查新Seurat对象中的细胞数量
table(sce.need@meta.data$cl295v11SubShort)
# 确保 metatable 的行名为 cellID，以便后续合并
rownames(metatable) <- metatable$cellID
# 检查 metatable 的 cellID 和 sce.need 的细胞名称是否一致
all(rownames(sce.need@meta.data) %in% rownames(metatable)) # 应该返回 TRUE
# 仅保留与 sce.need 匹配的 cellID 行
metatable_filtered <- metatable[rownames(sce.need@meta.data), ]
# 将表型信息合并到 Seurat 对象的 meta.data 中
sce.need@meta.data <- cbind(sce.need@meta.data, metatable_filtered)
# 检查合并后的 meta.data 表
head(sce.need@meta.data)
table(sce.need@meta.data$MMRStatus)
library(qs)
qsave(sce.need,"sce.need.qs")

sce.need=qread("sce.need.qs")
# 提取 MMRd 细胞的 Seurat 对象
sce_MMRd <- subset(sce.need, subset = MMRStatus == "MMRd")
# 提取 MMRp 细胞的 Seurat 对象
sce_MMRp <- subset(sce.need, subset = MMRStatus == "MMRp")
# 检查两个对象中的细胞数量
table(sce.need@meta.data$MMRStatus)
cat("MMRd 细胞数量:", ncol(sce_MMRd), "\n")
cat("MMRp 细胞数量:", ncol(sce_MMRp), "\n")
qsave(sce_MMRp,"sce_MMRp.qs")
qsave(sce_MMRd,"sce_MMRd.qs")


#######fibro 细胞
selected_subtypes <- c(
  "cS21", "cS22", "cS23", "cS24", "cS25", "cS26", "cS27", "cS28", "cS29", "cS30", "cS31"
)
sce.need.fibro=subset(sce.need, subset = cl295v11SubShort %in% selected_subtypes) %>% 
  process_single_cell_noharomny() %>% qsave(file = "sce.need.fibro.qs")

sce.need.fibro=qread("sce.need.fibro.qs") 
DimPlot(sce.need.fibro,group.by = "cl295v11SubFull",label = T)
DimPlot(sce.need.fibro,reduction = "umap",group.by = "orig.ident",label = T)
check_genes = c(  "CXCL12","CXCL13",
                  "CXCR5","CCL8",#找到目标fibro
                  )
Idents(object = sce.need.fibro) <- "RNA_snn_res.0.1"
DotPlot(object = sce.need.fibro, features = check_genes,assay = "RNA",scale = T) + 
  coord_flip()+scale_color_gradientn(colours = c('#330066','#336699','#66CC66','#FFCC33')) 

marker.Find <- FindAllMarkers(object = sce.need.fibro, 
                              only.pos = T,
                              min.pct = 0.2,
                              logfc.threshold = 0.25,
                              test.use="wilcox")
marker.Find %>% dplyr::group_by(cluster) %>% dplyr::top_n(n = 15, wt = avg_log2FC) %>% print(n=500)
qsave(marker.Find,"marker.Find.fibro.qs")

celltype <- c(
  "0"="CAF_C1_INHBA",
  "1"="CAF_C2_CXCL12",
  "2"="CAF_C3_CCL13",
  "3"="CAF_C4_CXCL14",
  "4"="CAF_C5_GREM1",
  "5"="Myofibroblasts",
  "6"="Fibro stem cell"
)
sce.need.fibro <- RenameIdents(sce.need.fibro, celltype)
sce.need.fibro$celltype <- sce.need.fibro@active.ident
p1=DimPlot(sce.need.fibro, label = T,group.by = "celltype",pt.size = 0.5)
p2=FeaturePlot(sce.need.fibro,"CXCL12")
p1+p2
##########保存数据
library(qs)
qsave(sce.need.fibro, file = "sce.need.fibro.qs")

#######mye 细胞
selected_subtypes <- c(
  "cM03", "cM04", "cM05", "cM06", "cM07", "cM08", "cM09")
sce.need.mye=subset(sce.need, subset = cl295v11SubShort %in% selected_subtypes)
sce.need.mye=process_single_cell(sce.need.mye)
qsave(sce.need.mye,file = "sce.need.mye.qs")

sce.need.mye=qread("sce.need.mye.qs")
DimPlot(sce.need.mye,group.by = "cl295v11SubFull",label = T)
DimPlot(sce.need.mye,reduction = "umap",group.by = "orig.ident",label = T)

check_genes = c( "IRF4", "IRF7", "IRF8", "SPIB", "SOX4",#pDC
                 "HMGA1", "PFDN1", #cDC2
                 "BATF3", "ID2", "ETV3",#cDC1
                 "APOE","C1QA",'C1QB',#Macrophage
                 "FCGR3A",#CD16
                 "CD14",#CD14
                 "CR1","CXCL13","ICAM1","CXCR5",#找到fDC
                 "LAMP1","LAMP2","LAMP3",#LAMP+DC
                 "VCAM1"
)
Idents(object = sce.need.mye) <- "RNA_snn_res.0.1"
DimPlot(sce.need.mye,reduction = "umap",label = T)
DotPlot(object = sce.need.mye, features = check_genes,assay = "RNA",scale = T) + 
  coord_flip()+scale_color_gradientn(colours = c('#330066','#336699','#66CC66','#FFCC33')) 

marker.Find <- FindAllMarkers(object = sce.need.mye, 
                              only.pos = T,
                              min.pct = 0.2,
                              logfc.threshold = 0.25,
                              test.use="wilcox")
marker.Find %>% dplyr::group_by(cluster) %>% dplyr::top_n(n = 15, wt = avg_log2FC) %>% print(n=500)
qsave(marker.Find,"marker.Find.mye.qs")
mark.Find=qread("marker.Find.mye.qs")

sce.need.mye=subset(sce.need.mye,idents=c("3","6","9"),invert=T)
celltype <- c(
  "0"="cDC2_CD1C",
  "1"="DC_LAMP3",
  "2"="pDC",
  "4"="cDC2_C1Q+",
  "5"="DC_IL22RA2",
  "7"="cDC1",
  "8"="AS-DC"
)
sce.need.mye <- RenameIdents(sce.need.mye, celltype)
sce.need.mye$celltype <- sce.need.mye@active.ident
p1=DimPlot(sce.need.mye, label = T,group.by = "celltype",pt.size = 0.5)
p2=FeaturePlot(sce.need.mye,"HMGB1")
p1+p2
qsave(sce.need.mye,"sce.need.mye.qs")

#######endo 细胞
selected_subtypes <- c(
  "cS01", "cS02", "cS03", "cS04", "cS05", "cS06", "cS07", "cS08", "cS09", "cS10", "cS11", "cS12", "cS13", "cS14")
sce.need.endo=subset(sce.need, subset = cl295v11SubShort %in% selected_subtypes) %>% 
  process_single_cell_noharomny() %>% qsave(file = "sce.need.endo.qs")

sce.need.endo=qread("sce.need.endo.qs")
check_genes = c(
  "PECAM1", "CDH5","CLDN5", # 动脉和静脉内皮细胞标记
  "VWF", # 血管内皮细胞通用标记
  "CCL21", "PROX1", # 淋巴管内皮细胞标记
  "HEY1", "IGFBP3", # 动脉特异性内皮细胞标记
  "CD36","CA4", # capillaries 
  "ACKR1" # vein
)

DimPlot(sce.need.endo,group.by = "cl295v11SubFull",label = T)

Idents(object = sce.need.endo) <- "RNA_snn_res.0.3"
DimPlot(sce.need.endo,reduction = "umap",label = T)
DotPlot(object = sce.need.endo, features = check_genes,assay = "RNA",scale = T) + 
  coord_flip()+scale_color_gradientn(colours = c('#330066','#336699','#66CC66','#FFCC33')) 

marker.Find <- FindAllMarkers(object = sce.need.endo, 
                              only.pos = T,
                              min.pct = 0.2,
                              logfc.threshold = 0.25,
                              test.use="wilcox")
marker.Find %>% dplyr::group_by(cluster) %>% dplyr::top_n(n = 15, wt = avg_log2FC) %>% print(n=500)
qsave(marker.Find,"marker.Find.endo.qs")

sce.need.endo=subset(sce.need.endo,idents=c("11","9"),invert=T)
celltype <- c(
  "0"="EC1_COL4A1", 
  "1"="EC2_vein_IL2R1", 
  "2"="EC3_capillary_CTGF", 
  "4"="EC4_vein_VCAN", 
  "5"="EC5_artery_SERPINE2", 
  "6"="EC6_artery_GJA4", 
  "7"="EC7_lymphatic_CCL21", 
  "8"="EC8_proliferation", 
  "3"="perivascular‐like cell", 
  "10"="EMT"
)
sce.need.endo <- RenameIdents(sce.need.endo, celltype)
sce.need.endo$celltype <- sce.need.endo@active.ident
DimPlot(sce.need.endo, label = T,group.by = "celltype",pt.size = 0.5)
FeaturePlot(sce.need.endo,c("VCAM1","FABP4"))
#######T 细胞
selected_subtypes <- c(
  "cTNI01", "cTNI02", "cTNI03", "cTNI04", "cTNI05", "cTNI06", "cTNI07", "cTNI08", "cTNI09",
  "cTNI10", "cTNI11", "cTNI12", "cTNI13", "cTNI14", "cTNI15", "cTNI16", "cTNI17", "cTNI18", "cTNI19", "cTNI20", "cTNI21", "cTNI22"
)
sce.need.T=subset(sce.need, subset = cl295v11SubShort %in% selected_subtypes) %>% 
  process_single_cell_noharomny() %>% qsave(file = "sce.need.T.qs")

sce.need.T=qread("sce.need.T.qs")
DimPlot(sce.need.T,reduction = "umap",group.by = "cl295v11SubFull",label = T)
annotation=readxl::read_xlsx("T细胞分群.原文.xlsx",sheet = 9)
annotation[1:5,1:5]
# 筛选包含 PDCD1 的 Cell_type
pdcd1_cells <- unique(annotation$Cell_type[annotation$geneID == "PDCD1"])
# 筛选包含 CXCL13 的 Cell_type
cxcl13_cells <- unique(annotation$Cell_type[annotation$geneID == "CXCL13"])
# 找出同时包含 PDCD1 和 CXCL13 的 Cell_type
common_cells <- intersect(pdcd1_cells, cxcl13_cells)
common_cells

#######B 细胞
selected_subtypes <- c(
  "cB1", "cB2", "cB3",
  "cP1", "cP2", "cP3")
sce.need.B=subset(sce.need, subset = cl295v11SubShort %in% selected_subtypes)
sce.need.B=process_single_cell(sce.need.B)
qsave(sce.need.B,file = "sce.need.B.qs")

sce.need.B=qread("sce.need.B.qs")
sce.need.B=FindClusters(sce.need.B,resolution = 0.2, algorithm = 1)
Idents(object = sce.need.B) <- "RNA_snn_res.0.5"
DimPlot(sce.need.B,group.by = "cl295v11SubFull",label = T)
DimPlot(sce.need.B,reduction = "umap",label = T)
DimPlot(sce.need.B,reduction = "umap",group.by = "orig.ident",label = T)
check_genes = c("CD19", "MS4A1", #B cell
                "IGHA1",#igA plasma
                "IGHG1",#igG plasma
                "SDC1",#plasma cell
                "AIM2", "TNFRSF13B", "CD27",#memory B
                "IGHD","IGHM","FCER2", "TCL1A",#naive B
                "MKI67","MME",##增殖marker
                "LRMP","SUGCT","IL4R","AICD1","BCL6",#GC B
                "CD3E","CD3B"
)
DotPlot(object = sce.need.B, features = check_genes,assay = "RNA",scale = T) + 
  coord_flip()+scale_color_gradientn(colours = c('#330066','#336699','#66CC66','#FFCC33')) #颜色
FeaturePlot(sce.need.B,features = c("IGHA1","IGHG1"))
marker.Find <- FindAllMarkers(object = sce.need.B, 
                              only.pos = T,
                              min.pct = 0.2,
                              logfc.threshold = 0.25,
                              test.use="wilcox")
marker.Find %>% dplyr::group_by(cluster) %>% dplyr::top_n(n = 15, wt = avg_log2FC) %>% print(n=500)
sce.need.B=subset(sce.need.B,idents=c("5","10","12","13","14"),invert=T)
celltype <- c(
  "1"="memory B",
  "3"="naive B",
  "6"="GC B(MKI67)",
  "7"="GC B",
  "4"="IgG Plasma cell",
  "9"="IgA Plasma cell",
  "2"="IgA Plasma cell",
  "0"="IgA Plasma cell",
  "8"="IgA Plasma cell",
  "11"="IgA Plasma cell"
)
sce.need.B <- RenameIdents(sce.need.B, celltype)
sce.need.B$celltype <- sce.need.B@active.ident
p1=DimPlot(sce.need.B, label = T,group.by = "celltype",pt.size = 0.5)
p2=FeaturePlot(sce.need.B,"BCL6")
p1+p2
##########保存数据
library(qs)
qsave(sce.need.B, file = "sce.need.B.qs")
##跑以前的代码直接出
sce.need.B=qread("sce.need.B.qs")
library(monocle3)

data <- GetAssayData(sce.need.B, assay = 'RNA', slot = 'counts')
cell_metadata <- sce.need.B@meta.data
gene_annotation <- data.frame(gene_short_name = rownames(data))
rownames(gene_annotation) <- rownames(data)
cds <- new_cell_data_set(data,
                         cell_metadata = cell_metadata,
                         gene_metadata = gene_annotation)
#preprocess_cds函数相当于seurat中NormalizeData+ScaleData+RunPCA
cds <- preprocess_cds(cds, num_dim = 50)
#umap降维
cds <- reduce_dimension(cds, preprocess_method = "PCA")

cds=cluster_cells(cds,reduction_method = "UMAP")
cds <- learn_graph(cds)
cds <- order_cells(cds)

p=plot_cells(cds,
           color_cells_by = "pseudotime",
           label_cell_groups=FALSE,
           label_leaves=F,
           label_branch_points=F,
           graph_label_size=3)
library(scvelo)

