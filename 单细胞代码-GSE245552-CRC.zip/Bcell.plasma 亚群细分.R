##############################定义一个函数，减少代码
process_single_cell <- function(sce, scale.factor = 10000, nfeatures = 2000, pcs_threshold = 90, variation_diff = 0.1) {
  # Normalize the data
  sce <- NormalizeData(sce, normalization.method = "LogNormalize", scale.factor = scale.factor)
  # Find variable features
  sce <- FindVariableFeatures(sce, selection.method = "vst", nfeatures = nfeatures)
  # Scale the data
  sce <- ScaleData(sce, features = rownames(sce))
  # Run PCA
  sce <- RunPCA(sce, features = VariableFeatures(object = sce)) 
  library(harmony)
  sce=RunHarmony(sce,"orig.ident")
  # Calculate percent of variance explained by each principal component
  pct <- sce[["harmony"]]@stdev / sum(sce[["harmony"]]@stdev) * 100 
  # Calculate cumulative percentages
  cumu <- cumsum(pct)
  # Find the first PC where the cumulative percentage exceeds 90% and individual % variance is < 5%
  co1 <- which(cumu > pcs_threshold & pct < 5)[1]
  # Find the PC where the difference between consecutive PCs is more than 0.1%
  co2 <- sort(which((pct[1:length(pct) - 1] - pct[2:length(pct)]) > variation_diff), decreasing = TRUE)[1] + 1
  # Select the minimum of the two as the number of PCs to use
  pcs <- min(co1, co2)
  # Run UMAP
  sce <- RunUMAP(sce, reduction = 'harmony', dims = 1:pcs)
  sce <- FindNeighbors(sce,reduction = 'harmony',dims = 1:pcs)
  # Plot UMAP with different clustering resolutions
  for (res in c(0.05,0.1,0.3,0.5,0.8,1,1.2,1.4,1.5,2)){
    print(res)
    sce <- FindClusters(sce, resolution = res, algorithm = 1)%>% 
      identity()
  }
  # Return the processed Seurat object
  return(sce)
}
process_single_cell_noharomny <- function(sce, scale.factor = 10000, nfeatures = 2000, pcs_threshold = 90, variation_diff = 0.1) {
  # Normalize the data
  sce <- NormalizeData(sce, normalization.method = "LogNormalize", scale.factor = scale.factor)
  # Find variable features
  sce <- FindVariableFeatures(sce, selection.method = "vst", nfeatures = nfeatures)
  # Scale the data
  sce <- ScaleData(sce, features = rownames(sce))
  # Run PCA
  sce <- RunPCA(sce, features = VariableFeatures(object = sce)) 
  # Calculate percent of variance explained by each principal component
  pct <- sce[["pca"]]@stdev / sum(sce[["pca"]]@stdev) * 100 
  # Calculate cumulative percentages
  cumu <- cumsum(pct)
  # Find the first PC where the cumulative percentage exceeds 90% and individual % variance is < 5%
  co1 <- which(cumu > pcs_threshold & pct < 5)[1]
  # Find the PC where the difference between consecutive PCs is more than 0.1%
  co2 <- sort(which((pct[1:length(pct) - 1] - pct[2:length(pct)]) > variation_diff), decreasing = TRUE)[1] + 1
  # Select the minimum of the two as the number of PCs to use
  pcs <- min(co1, co2)
  # Run UMAP
  sce <- RunUMAP(sce, reduction = 'pca', dims = 1:pcs)
  sce <- FindNeighbors(sce,reduction = 'pca',dims = 1:pcs)
  # Plot UMAP with different clustering resolutions
  for (res in c(0.05,0.1,0.3,0.5,0.8,1,1.2,1.4,1.5,2)){
    print(res)
    sce <- FindClusters(sce, resolution = res, algorithm = 1)%>% 
      identity()
  }
  # Return the processed Seurat object
  return(sce)
}

##########
sce.Bcell.plasma=qread("sce.Bcell.plasma.qs") %>% process_single_cell()
DimPlot(sce.Bcell.plasma,reduction = "umap",label = T)
cluster_umap <- wrap_plots(ncol = 5,
                           DimPlot(sce.Bcell.plasma, reduction = "umap", group.by = "RNA_snn_res.0.05", label = T) & NoAxes(),  
                           DimPlot(sce.Bcell.plasma, reduction = "umap", group.by = "RNA_snn_res.0.1", label = T) & NoAxes(),
                           DimPlot(sce.Bcell.plasma, reduction = "umap", group.by = "RNA_snn_res.0.3", label = T)& NoAxes(),
                           DimPlot(sce.Bcell.plasma, reduction = "umap", group.by = "RNA_snn_res.0.5", label = T) & NoAxes(),
                           DimPlot(sce.Bcell.plasma, reduction = "umap", group.by = "RNA_snn_res.0.8", label = T) & NoAxes(), 
                           DimPlot(sce.Bcell.plasma, reduction = "umap", group.by = "RNA_snn_res.1", label = T) & NoAxes(),
                           DimPlot(sce.Bcell.plasma, reduction = "umap", group.by = "RNA_snn_res.1.2", label = T) & NoAxes(),
                           DimPlot(sce.Bcell.plasma, reduction = "umap", group.by = "RNA_snn_res.1.4", label = T)& NoAxes(),
                           DimPlot(sce.Bcell.plasma, reduction = "umap", group.by = "RNA_snn_res.1.5", label = T)& NoAxes()
)
cluster_umap
Idents(object = sce.Bcell.plasma) <- "RNA_snn_res.0.1"

marker.Find <- FindAllMarkers(object = sce.Bcell, 
                              only.pos = T,
                              min.pct = 0.2,
                              logfc.threshold = 0.25,
                              test.use="wilcox")
marker.Find %>% dplyr::group_by(cluster) %>% dplyr::top_n(n = 15, wt = avg_log2FC) %>% print(n=500)
sce.Bcell.plasma=subset(sce.Bcell.plasma,idents=c("4","6"),inver=T)


check_genes = c("CD19", "MS4A1", "IGHM", "IGHG1", "CD27", "CD38","CD14",
                "SDC1",#浆细胞的CD138
                "IGHD",#naive B
                "MKI67","MME",##增殖marker
                "LRMP","SUGCT","IL4R","AICD1"#GC B
                )

DotPlot(object = sce.Bcell.plasma, features = check_genes,assay = "RNA",scale = T) + 
  coord_flip()
#################1.B cell
sce.Bcell=subset(sce.Bcell.plasma,idents="1")
DimPlot(sce.Bcell,reduction = "umap",label = T,group.by = "orig.ident")

sce.Bcell=process_single_cell_noharomny(sce.Bcell)

Idents(object = sce.Bcell) <- "RNA_snn_res.0.8"
DimPlot(sce.Bcell,reduction = "umap",label = T)

marker.Find <- FindAllMarkers(object = sce.Bcell, 
                              only.pos = T,
                              min.pct = 0.2,
                              logfc.threshold = 0.25,
                              test.use="wilcox")
marker.Find %>% dplyr::group_by(cluster) %>% dplyr::top_n(n = 15, wt = avg_log2FC) %>% print(n=500)

########开始注释Bcell
###0 2 3 4 5 memory B
###1 6 naive B
###7 GC B
sce.Bcell=subset(sce.Bcell,idents="8",invert=T)
celltype  <- c(
  "0"="memory B cell",
  "2"="memory B cell",
  "3"="memory B cell",
  "4"="memory B cell",
  "5"="memory B cell",
  "1"="naive B cell",
  "6"="naive B cell",
  "7"="GC B cell"
)
sce.Bcell <- RenameIdents(sce.Bcell, celltype)
sce.Bcell$celltype <- sce.Bcell@active.ident
DimPlot(sce.Bcell, label = T,group.by = "celltype",pt.size = 0.5)
##########保存数据
library(qs)
qsave(sce.Bcell, file = "~/CRC/sce.Bcell.亚群细分完成.qs")
########2.plasma cell
sce.plasma=subset(sce.Bcell.plasma,idents=c("3","0","7","2","5"))

sce.plasma=process_single_cell_noharomny(sce.plasma)

DimPlot(sce.plasma,reduction = "umap",label = T,group.by = "orig.ident")
Idents(object = sce.plasma) <- "RNA_snn_res.0.3"
check_genes = c("IGHA1",#igA plasma
                "IGHG1","IGHG3","IGHG4",#igG plasma
                "SDC1"
)
DotPlot(object = sce.plasma, features = check_genes,assay = "RNA",scale = T) + 
  coord_flip()

marker.Find <- FindAllMarkers(object = sce.plasma, 
                              only.pos = T,
                              min.pct = 0.2,
                              logfc.threshold = 0.25,
                              test.use="wilcox")
marker.Find %>% dplyr::group_by(cluster) %>% dplyr::top_n(n = 15, wt = avg_log2FC) %>% print(n=500)

celltype  <- c(
  "2"="IgG+ Plasma",
  "3"="IgG+ Plasma",
  "6"="IgG+ Plasma",
  "0"="IgA+ Plasma",
  "1"="IgA+ Plasma",
  "4"="IgA+ Plasma",
  "5"="IgA+ Plasma"
)
sce.plasma <- RenameIdents(sce.plasma, celltype)
sce.plasma$celltype <- sce.plasma@active.ident
DimPlot(sce.plasma, label = T,group.by = "celltype",pt.size = 0.5)
##########保存数据
library(qs)
qsave(sce.plasma, file = "~/CRC/sce.plasma.亚群细分完成.qs")

