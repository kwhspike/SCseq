setwd("~/CRC/GSE245552_RAW")
library(Seurat)
fs=list.files('./','^GSM')
library(stringr)
samples=str_split(fs,'_',simplify = T)[,1]
lapply(unique(samples),function(x){
  y=fs[grepl(x,fs)]
  folder=paste(str_split(y[1],'_',simplify = T)[,1],collapse = '')
  dir.create(folder,recursive = T)
  file.rename(y[1],file.path(folder,"barcodes.tsv.gz"))
  file.rename(y[2],file.path(folder,"feature.tsv.gz"))
  file.rename(y[3],file.path(folder,"matrix.mtx.gz"))
})


library(GEOquery)
gse <- getGEO(filename = "~/CRC/GSE245552_family.soft.gz")
gsm_names <- names(gse@gsms)[grepl("^GSM", names(gse@gsms))]
# 现在，我们将使用 lapply 函数来提取每个以 GSM 开头的变量的 header 属性
source <- lapply(gsm_names, function(gsm_name) {
  gse@gsms[[gsm_name]]@header$source_name_ch1
})
df <- data.frame(gsm_names,unlist(source))
PT <- subset(df, unlist.source. == "primary tumor")$gsm_names
LM= subset(df, unlist.source. == "liver metastasis")$gsm_names
#######提取出了PT(primary tumor)和LM（liver metastatic）的gsm号

sceList.LM = lapply(LM,function(x){ 
  CreateSeuratObject(counts = Read10X(x), 
                     project = x )
})
sceList.PT = lapply(PT,function(x){ 
  CreateSeuratObject(counts = Read10X(x), 
                     project = x )
})

# 使用 lapply 函数将这些元素合并成一个 Seurat 对象
sce.LM <- Reduce(function(x, y) merge(x, y), sceList.LM)
sce.LM$group="LM"
sce.PT<- Reduce(function(x, y) merge(x, y), sceList.PT)
sce.PT$group="PT"
sce=merge(sce.LM,sce.PT)
save(sce,file = '~/CRC/sce.Rdata')

library(future)
plan("multicore", workers = 10)
options(future.globals.maxSize =  10000000000000) #  GiB的全局变量
sce <- PercentageFeatureSet(sce,pattern = '^MT',col.name = 'percent.MT')
sce <- PercentageFeatureSet(sce,pattern = '^RP[SL]',col.name = 'percent.RP')
# 过滤细胞
sce <- subset(sce,subset = nFeature_RNA<6000 & nFeature_RNA>200 & percent.MT<20)
dim(sce) 
# 过滤gene
sce <- sce[rowSums(sce@assays$RNA@counts>0)>3,]
dim(sce) 


sce <- NormalizeData(sce, normalization.method = "LogNormalize", scale.factor = 10000)
sce <- FindVariableFeatures(sce, selection.method = "vst", nfeatures = 2000)
sce <- ScaleData(sce, features = rownames(sce))

#sce <- RunPCA(sce)
library(harmony)
sce=RunHarmony(sce,"orig.ident")
save(sce,file = '~/CRC/sce.afterQC.afterharmony.Rdata')
pct <- sce[["harmony"]]@stdev / sum(sce[["harmony"]]@stdev) * 100
# Calculate cumulative percents for each PC
cumu <- cumsum(pct)
# Determine which PC exhibits cumulative percent greater than 90% and % variation associated with the PC as less than 5
co1 <- which(cumu > 90 & pct < 5)[1]
co1
# Determine the difference between variation of PC and subsequent PC
co2 <- sort(which((pct[1:length(pct) - 1] - pct[2:length(pct)]) > 0.1), decreasing = T)[1] + 1
# last point where change of % of variation is more than 0.1%.
co2
# Minimum of the two calculation
pcs <- min(co1, co2)
pcs

sce <- RunUMAP(sce,reduction = 'harmony',dims = 1:30)
DimPlot(sce, reduction = "umap", raster=FALSE)
sce <- FindNeighbors(sce,reduction = 'harmony',dims = 1:30)
sce <- FindClusters(sce, resolution = 0.5, algorithm = 1)
for (res in c(0.05,0.1,0.3,0.5,0.8,1,1.2,1.4,1.5,2)){
  print(res)
  sce <- FindClusters(sce, resolution = res, algorithm = 1)%>% 
    identity()
}
options(repr.plot.width = 20, repr.plot.height = 8)
#umap可视化
library(patchwork)
cluster_umap <- wrap_plots(ncol = 5,
                           DimPlot(sce, reduction = "umap", group.by = "RNA_snn_res.0.05", label = T) & NoAxes(),  
                           DimPlot(sce, reduction = "umap", group.by = "RNA_snn_res.0.1", label = T) & NoAxes(),
                           DimPlot(sce, reduction = "umap", group.by = "RNA_snn_res.0.3", label = T)& NoAxes(),
                           DimPlot(sce, reduction = "umap", group.by = "RNA_snn_res.0.5", label = T) & NoAxes(),
                           DimPlot(sce, reduction = "umap", group.by = "RNA_snn_res.0.8", label = T) & NoAxes(), 
                           DimPlot(sce, reduction = "umap", group.by = "RNA_snn_res.1", label = T) & NoAxes(),
                           DimPlot(sce, reduction = "umap", group.by = "RNA_snn_res.1.2", label = T) & NoAxes(),
                           DimPlot(sce, reduction = "umap", group.by = "RNA_snn_res.1.4", label = T)& NoAxes(),
                           DimPlot(sce, reduction = "umap", group.by = "RNA_snn_res.1.5", label = T)& NoAxes()
)
cluster_umap

# 选择0.3合适的分辨率
save(sce,file = '~/CRC/sce.分群后.Rdata')
Idents(object = sce) <- "RNA_snn_res.0.5"
DimPlot(sce, reduction = "umap", group.by = "RNA_snn_res.0.5",label = T,raster=FALSE)
marker.Find <- FindAllMarkers(object = sce, 
                              only.pos = T,
                              min.pct = 0.2,
                              logfc.threshold = 0.25,
                              test.use="wilcox")
markers <- FindMarkers(sce, ident.1 = "14",
                       only.pos = T,
                       min.pct = 0.2,
                       logfc.threshold = 0.25,
                       test.use="wilcox")
marker.Find %>% dplyr::group_by(cluster) %>% dplyr::top_n(n = 15, wt = avg_log2FC) %>% print(n=500)
save(marker.Find,file = '~/CRC/Marker.Rdata')

library(ggplot2)
options(repr.plot.width = 7.5, repr.plot.height = 8)
check_genes="PTPRC"


## 红细胞和增殖细胞
check_genes = c("HBB","HBA1","HBA2", # 红细胞,Erythroid cells
                "PPBP","GP1BB", # Platelets
                'MKI67','TOP2A' #Cell cycling
)
####肿瘤细胞 内皮 上皮 成纤维
check_genes = c( "EPCAM","SOX9" ,"MKI67","KRT8","CEACAM5","TOP2A",#tumor cell
                 "COL1A1" ,"COL1A2" ,#fibra cells
                 "PECAM1" , "CD34" #endothelial cells
)
######immune cell
#####B细胞
check_genes = c( "IGHM","CD22","CD79A","CD19","MS4A1","SDC1", #B cells
                 "JCHAIN","MZB1","PRDM1","IGJ" #Plasma cells
)
#####T cell
check_genes = c( "CD3E","CD3G","CD4", #CD4 T cells
                 "CD8A"#CD8 T cells
)
#####
check_genes = c( "FOXP3",#Treg cells
                 "APOE","C1QA",'C1QB',"FCGR3A"#Macrophage
)
#####DC
check_genes = c( "IRF4", "IRF7", "IRF8", "SPIB", "SOX4",#pDC
                 "HMGA1", "PFDN1", #cDC2
                 "BATF3", "ID2", "ETV3"#cDC1
)

DotPlot(object = sce, features = check_genes,assay = "RNA",scale = T) + 
  coord_flip()
#####注释结束
sce <- subset(sce, idents = "18", invert = TRUE)
celltype  <- c(
  "0"="tumor cell",
  "15"="tumor cell",
  "5"="tumor cell",
  "8"="tumor cell",
  "11"="Fibroblast",
  "9"="Fibroblast",
  "13"="endothelial",
  "1"="T cell",
  "19"="T cell",
  "7"="T cell",
  "2"="T cell",
  "17"="B cell/plasma",
  "3"="B cell/plasma",
  "10"="B cell/plasma",
  "16"="Myelocyte",
  "4"="Myelocyte",
  "12"="Myelocyte",
  "6"="Myelocyte",
  "14"="Myelocyte"
)
sce <- RenameIdents(sce, celltype)
sce$celltype <- sce@active.ident
DimPlot(sce, label = T,group.by = "celltype",pt.size = 0.5)
sce.nonimmune=subset(sce,idents=c("tumor cell","endothelial","Fibroblast"))
sce.mye=subset(sce,idents="Myelocyte")
sce.Tcell=subset(sce,idents="T cell")
sce.Bcell.plasma=subset(sce,idents="B cell/plasma")
##########保存数据
library(qs)
qsave(sce.Bcell.plasma, file = "~/CRC/sce.Bcell.plasma.qs")
qsave(sce.Tcell, file = "~/CRC/sce.Tcell.qs")
qsave(sce.mye, file = "~/CRC/sce.mye.qs")
qsave(sce.nonimmune, file = "~/CRC/sce.nonimmune.qs")



sce.mye=qread("sce.mye.qs") %>% process_single_cell()
