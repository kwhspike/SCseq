##############################定义一个函数，减少代码
process_single_cell <- function(sce, scale.factor = 10000, nfeatures = 2000, pcs_threshold = 90, variation_diff = 0.1) {
  # Normalize the data
  sce <- NormalizeData(sce, normalization.method = "LogNormalize", scale.factor = scale.factor)
  # Find variable features
  sce <- FindVariableFeatures(sce, selection.method = "vst", nfeatures = nfeatures)
  # Scale the data
  sce <- ScaleData(sce, features = rownames(sce))
  library(harmony)
  sce=RunHarmony(sce,"orig.ident",project.dim = F)
  # Calculate percent of variance explained by each principal component
  pct <- sce[["harmony"]]@stdev / sum(sce[["harmony"]]@stdev) * 100 
  # Calculate cumulative percentages
  cumu <- cumsum(pct)
  # Find the first PC where the cumulative percentage exceeds 90% and individual % variance is < 5%
  co1 <- which(cumu > pcs_threshold & pct < 5)[1]
  # Find the PC where the difference between consecutive PCs is more than 0.1%
  co2 <- sort(which((pct[1:length(pct) - 1] - pct[2:length(pct)]) > variation_diff), decreasing = TRUE)[1] + 1
  # Select the minimum of the two as the number of PCs to use
  pcs <- min(co1, co2)
  # Run UMAP
  sce <- RunUMAP(sce, reduction = 'harmony', dims = 1:pcs)
  sce <- FindNeighbors(sce,reduction = 'harmony',dims = 1:pcs)
  # Plot UMAP with different clustering resolutions
  for (res in c(0.05,0.1,0.3,0.5,0.8,1)){
    print(res)
    sce <- FindClusters(sce, resolution = res, algorithm = 1)%>% 
      identity()
  }
  # Return the processed Seurat object
  return(sce)
}
process_single_cell_noharomny <- function(sce, scale.factor = 10000, nfeatures = 2000, pcs_threshold = 90, variation_diff = 0.1) {
  # Normalize the data
  sce <- NormalizeData(sce, normalization.method = "LogNormalize", scale.factor = scale.factor)
  # Find variable features
  sce <- FindVariableFeatures(sce, selection.method = "vst", nfeatures = nfeatures)
  # Scale the data
  sce <- ScaleData(sce, features = rownames(sce))
  # Run PCA
  sce <- RunPCA(sce, features = VariableFeatures(object = sce)) 
  # Calculate percent of variance explained by each principal component
  pct <- sce[["pca"]]@stdev / sum(sce[["pca"]]@stdev) * 100 
  # Calculate cumulative percentages
  cumu <- cumsum(pct)
  # Find the first PC where the cumulative percentage exceeds 90% and individual % variance is < 5%
  co1 <- which(cumu > pcs_threshold & pct < 5)[1]
  # Find the PC where the difference between consecutive PCs is more than 0.1%
  co2 <- sort(which((pct[1:length(pct) - 1] - pct[2:length(pct)]) > variation_diff), decreasing = TRUE)[1] + 1
  # Select the minimum of the two as the number of PCs to use
  pcs <- min(co1, co2)
  # Run UMAP
  sce <- RunUMAP(sce, reduction = 'pca', dims = 1:pcs)
  sce <- FindNeighbors(sce,reduction = 'pca',dims = 1:pcs)
  # Plot UMAP with different clustering resolutions
  for (res in c(0.05,0.1,0.3,0.5,0.8,1)){
    print(res)
    sce <- FindClusters(sce, resolution = res, algorithm = 1)%>% 
      identity()
  }
  # Return the processed Seurat object
  return(sce)
}
plot_umap_clusters_fixed <- function(seurat_object, ncol = 5) {
  # 固定的分辨率列表
  resolution_list <- c(0.05, 0.1, 0.3, 0.5, 0.8, 1)
  # 使用 lapply 动态生成 DimPlot 列表
  plot_list <- lapply(resolution_list, function(resolution) {
    DimPlot(seurat_object, reduction = "umap", group.by = paste0("RNA_snn_res.", resolution), label = TRUE) & NoAxes()
  })
  # 将所有的图形拼接到一个 UMAP 图中
  cluster_umap <- wrap_plots(ncol = ncol, plot_list)
  # 返回拼接的 UMAP 图
  return(cluster_umap)
}
##########
sce.Tcell=qread("sce.Tcell.qs") %>% process_single_cell()
DimPlot(sce.Tcell,reduction = "umap",group.by = "orig.ident",label = T)
cluster_umap <- wrap_plots(ncol = 5,
                           DimPlot(sce.Tcell, reduction = "umap", group.by = "RNA_snn_res.0.05", label = T) & NoAxes(),  
                           DimPlot(sce.Tcell, reduction = "umap", group.by = "RNA_snn_res.0.1", label = T) & NoAxes(),
                           DimPlot(sce.Tcell, reduction = "umap", group.by = "RNA_snn_res.0.3", label = T)& NoAxes(),
                           DimPlot(sce.Tcell, reduction = "umap", group.by = "RNA_snn_res.0.5", label = T) & NoAxes(),
                           DimPlot(sce.Tcell, reduction = "umap", group.by = "RNA_snn_res.0.8", label = T) & NoAxes(), 
                           DimPlot(sce.Tcell, reduction = "umap", group.by = "RNA_snn_res.1", label = T) & NoAxes(),
                           DimPlot(sce.Tcell, reduction = "umap", group.by = "RNA_snn_res.1.2", label = T) & NoAxes(),
                           DimPlot(sce.Tcell, reduction = "umap", group.by = "RNA_snn_res.1.4", label = T)& NoAxes(),
                           DimPlot(sce.Tcell, reduction = "umap", group.by = "RNA_snn_res.1.5", label = T)& NoAxes()
)
cluster_umap
Idents(object = sce.Tcell) <- "RNA_snn_res.0.1"
marker.Find <- FindAllMarkers(object = sce.Tcell, 
                              only.pos = T,
                              min.pct = 0.2,
                              logfc.threshold = 0.25,
                              test.use="wilcox")
marker.Find %>% dplyr::group_by(cluster) %>% dplyr::top_n(n = 15, wt = avg_log2FC) %>% print(n=500)

check_genes = c( "CD3E","CD3G","CD4", #CD4 T cells
                 "CD8A",#CD8 T cells
                 "MKI67",#Cycling
                 "FOXP3",#Treg
                 "TRDC","KLRG1",#γδT
                 "NCAM1","KLRB1"#NKT
)
DimPlot(sce.Tcell,reduction = "umap",label = T)
DotPlot(object = sce.Tcell, features = check_genes,assay = "RNA",scale = T) + 
  coord_flip()
##########保存数据
library(qs)
qsave(sce.Tcell, file = "~/CRC/sce.Tcell.亚群细分完成.qs")
sce.Tcell=qread("sce.Tcell.亚群细分完成.qs")

#########CD4T
sce.CD4T=subset(sce.Tcell,idents=c("0","2","3","4")) %>% process_single_cell()
DimPlot(sce.CD4T,reduction = "umap",group.by="orig.ident",label = T)

Idents(object = sce.CD4T) <- "RNA_snn_res.0.8"
marker.Find <- FindAllMarkers(object = sce.CD4T, 
                              only.pos = T,
                              min.pct = 0.2,
                              logfc.threshold = 0.25,
                              test.use="wilcox")
marker.Find %>% dplyr::group_by(cluster) %>% dplyr::top_n(n = 25, wt = avg_log2FC) %>% print(n=1000)

check_genes = c( "CD3E","CD3G","CD4", #CD4 T cells
                 "CD8A",#CD8 T cells
                 "MKI67",#Cycling
                 "FOXP3",#Treg
                 "TRDC","KLRG1",#γδT
                 "NCAM1","KLRB1",#NKT
                 "CD27","CD28"#naive T
)
DimPlot(sce.CD4T,reduction = "umap",label = T)
DotPlot(object = sce.CD4T, features = check_genes,assay = "RNA",scale = T) + 
  coord_flip()
#######9和12删了
sce.CD4T=subset(sce.CD4T,idents=c("9","12"),invert=T)
##注释
celltype <- c(
  "13"="CD8+ Tn",
  "11"="Tfh cells",
  "10"="NK_C1",
  "8"="Treg_C1",
  "7"="CD4+ Tex",
  "6"="NK_C2",
  "5"="Treg_C2",
  "4"="CD4+ Tn",
  "3"="Treg_C3",
  "2"="Th17",
  "0"="CD4+ Tcm",
  "1"="CD4+ NKT"
)
sce.CD4T <- RenameIdents(sce.CD4T, celltype)
sce.CD4T$celltype <- sce.CD4T@active.ident
DimPlot(sce.CD4T, label = T,group.by = "celltype",pt.size = 0.5)
##########保存数据
library(qs)
qsave(sce.CD4T, file = "~/CRC/sce.CD4Tcell.亚群细分完成.qs")

########CD8
sce.CD8T=subset(sce.Tcell,idents=c("1","5","6")) %>% process_single_cell()
DimPlot(sce.CD8T,reduction = "umap",group.by="orig.ident",label = T)

cluster_umap=plot_umap_clusters_fixed(sce.CD8T)

Idents(object = sce.CD8T) <- "RNA_snn_res.0.3"
marker.Find <- FindAllMarkers(object = sce.CD8T, 
                              only.pos = T,
                              min.pct = 0.2,
                              logfc.threshold = 0.25,
                              test.use="wilcox")
marker.Find %>% dplyr::group_by(cluster) %>% dplyr::top_n(n = 20, wt = avg_log2FC) %>% print(n=1000)

DimPlot(sce.CD8T,reduction = "umap",label = T)

DotPlot(object = sce.CD8T, features = check_genes,assay = "RNA",scale = T) + 
  coord_flip()

celltype <- c(
  "7"="Treg_C4",
  "6"="γδ Tcell",
  "5"="Cycling Tcell",
  "4"="CD8+ NKT",
  "3"="MAIT",
  "2"="CD8+ Tex",
  "1"="CD8+ Trm",
  "0"="CD8+ Tem"
)
sce.CD8T <- RenameIdents(sce.CD8T, celltype)
sce.CD8T$celltype <- sce.CD8T@active.ident
DimPlot(sce.CD8T, label = T,group.by = "celltype",pt.size = 0.5)
##########保存数据
library(qs)
qsave(sce.CD8T, file = "~/CRC/sce.CD8Tcell.亚群细分完成.qs")
