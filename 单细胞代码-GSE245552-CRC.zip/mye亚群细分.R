##############################定义一个函数，减少代码
process_single_cell <- function(sce, scale.factor = 10000, nfeatures = 2000, pcs_threshold = 90, variation_diff = 0.1) {
  # Normalize the data
  sce <- NormalizeData(sce, normalization.method = "LogNormalize", scale.factor = scale.factor)
  # Find variable features
  sce <- FindVariableFeatures(sce, selection.method = "vst", nfeatures = nfeatures)
  # Scale the data
  sce <- ScaleData(sce, features = rownames(sce))
  library(harmony)
  sce=RunHarmony(sce,"orig.ident",project.dim = F)
  # Calculate percent of variance explained by each principal component
  pct <- sce[["harmony"]]@stdev / sum(sce[["harmony"]]@stdev) * 100 
  # Calculate cumulative percentages
  cumu <- cumsum(pct)
  # Find the first PC where the cumulative percentage exceeds 90% and individual % variance is < 5%
  co1 <- which(cumu > pcs_threshold & pct < 5)[1]
  # Find the PC where the difference between consecutive PCs is more than 0.1%
  co2 <- sort(which((pct[1:length(pct) - 1] - pct[2:length(pct)]) > variation_diff), decreasing = TRUE)[1] + 1
  # Select the minimum of the two as the number of PCs to use
  pcs <- min(co1, co2)
  # Run UMAP
  sce <- RunUMAP(sce, reduction = 'harmony', dims = 1:pcs)
  sce <- FindNeighbors(sce,reduction = 'harmony',dims = 1:pcs)
  # Plot UMAP with different clustering resolutions
  for (res in c(0.05,0.1,0.3,0.5,0.8,1)){
    print(res)
    sce <- FindClusters(sce, resolution = res, algorithm = 1)%>% 
      identity()
  }
  # Return the processed Seurat object
  return(sce)
}
process_single_cell_noharomny <- function(sce, scale.factor = 10000, nfeatures = 2000, pcs_threshold = 90, variation_diff = 0.1) {
  # Normalize the data
  sce <- NormalizeData(sce, normalization.method = "LogNormalize", scale.factor = scale.factor)
  # Find variable features
  sce <- FindVariableFeatures(sce, selection.method = "vst", nfeatures = nfeatures)
  # Scale the data
  sce <- ScaleData(sce, features = rownames(sce))
  # Run PCA
  sce <- RunPCA(sce, features = VariableFeatures(object = sce)) 
  # Calculate percent of variance explained by each principal component
  pct <- sce[["pca"]]@stdev / sum(sce[["pca"]]@stdev) * 100 
  # Calculate cumulative percentages
  cumu <- cumsum(pct)
  # Find the first PC where the cumulative percentage exceeds 90% and individual % variance is < 5%
  co1 <- which(cumu > pcs_threshold & pct < 5)[1]
  # Find the PC where the difference between consecutive PCs is more than 0.1%
  co2 <- sort(which((pct[1:length(pct) - 1] - pct[2:length(pct)]) > variation_diff), decreasing = TRUE)[1] + 1
  # Select the minimum of the two as the number of PCs to use
  pcs <- min(co1, co2)
  # Run UMAP
  sce <- RunUMAP(sce, reduction = 'pca', dims = 1:pcs)
  sce <- FindNeighbors(sce,reduction = 'pca',dims = 1:pcs)
  # Plot UMAP with different clustering resolutions
  for (res in c(0.05,0.1,0.3,0.5,0.8,1)){
    print(res)
    sce <- FindClusters(sce, resolution = res, algorithm = 1)%>% 
      identity()
  }
  # Return the processed Seurat object
  return(sce)
}
plot_umap_clusters_fixed <- function(seurat_object, ncol = 5) {
  # 固定的分辨率列表
  resolution_list <- c(0.05, 0.1, 0.3, 0.5, 0.8, 1)
  # 使用 lapply 动态生成 DimPlot 列表
  plot_list <- lapply(resolution_list, function(resolution) {
    DimPlot(seurat_object, reduction = "umap", group.by = paste0("RNA_snn_res.", resolution), label = TRUE) & NoAxes()
  })
  # 将所有的图形拼接到一个 UMAP 图中
  cluster_umap <- wrap_plots(ncol = ncol, plot_list)
  # 返回拼接的 UMAP 图
  return(cluster_umap)
}
##########
sce.mye=qread("sce.mye.qs") %>% process_single_cell()
####harmony之后仍然有离群样本，直接删掉
Idents(object = sce.mye) <- "orig.ident"
sce.mye <- subset(sce.mye, idents = "P5215-2",invert=T)
DimPlot(sce.mye,reduction = "umap",group.by = "orig.ident",label = T)

cluster_umap=plot_umap_clusters_fixed(sce.mye)

Idents(object = sce.mye) <- "RNA_snn_res.0.3"
marker.Find <- FindAllMarkers(object = sce.mye, 
                              only.pos = T,
                              min.pct = 0.2,
                              logfc.threshold = 0.25,
                              test.use="wilcox")
marker.Find %>% dplyr::group_by(cluster) %>% dplyr::top_n(n = 25, wt = avg_log2FC) %>% print(n=1000)
qsave(marker.Find,file = '~/CRC/Marker.qs')
check_genes = c( "IRF4", "IRF7", "IRF8", "SPIB", "SOX4",#pDC
                 "HMGA1", "PFDN1", #cDC2
                 "BATF3", "ID2", "ETV3",#cDC1
                 "APOE","C1QA",'C1QB',#Macrophage
                 "FCGR3A",#CD16
                 "CD14"#CD14
)

DotPlot(object = sce.mye, features = check_genes,assay = "RNA",scale = T) + 
  coord_flip()
DimPlot(sce.mye,reduction = "umap",label = T)


celltype <- c(
  "8"="pDC",
  "7"="cDC1",
  "4"="cDC2",
  "3"="Mast cell",
  "0"="Macrophage",
  "5"="Mono_C1",
  "2"="Mono_C2",
  "6"="TAM",
  "9"="neutrophil",
  "1"="neutrophil"
)

sce.mye <- RenameIdents(sce.mye, celltype)
sce.mye$celltype <- sce.mye@active.ident
DimPlot(sce.mye, label = T,group.by = "celltype",pt.size = 0.5)
##########保存数据
library(qs)
qsave(sce.mye, file = "~/CRC/sce.myecell.亚群细分完成.qs")
sce.mye=qread("sce.myecell.亚群细分完成.qs")
